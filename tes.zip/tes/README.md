<h1 align="center">ZyyPairing</h1>
<p align="center">
    <img src="https://github-production-user-asset-6210df.s3.amazonaws.com/141845356/269088895-1df53f8e-3406-49f0-97e4-f06c112d6155.jpg?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIAIWNJYAX4CSVEH53A%2F20230919%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20230919T203925Z&X-Amz-Expires=300&X-Amz-Signature=6fe97f46e15f897634477ed382bc3e03e8b98df741e80bc58ccbacc807a71208&X-Amz-SignedHeaders=host&actor_id=141845356&key_id=0&repo_id=693843145" width="60%" style="margin-left: auto;margin-right: auto;display: block;">
</p>
</p>
<p align="center">
<a href="https://github.com/rizzlogy"><img title="Author" src="https://img.shields.io/badge/AUTHOR-RizzyFuzz-blue.svg?style=for-the-badge&logo=github"></a>

---------

**[ INSTALLING NODEJS ]**

```bash
git clone https://github.com/rizzlogy/ZyyPairing.git
cd ZyyPairing
npm install
node . --use-pairing-code
```

---------
